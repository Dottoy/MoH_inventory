create definer = root@localhost view vw_patient_visit as
select `pt`.`patient_id`                                                   AS `patient_id`,
       concat(`pn`.`given_name`, if((`pn`.`middle_name` is not null), concat(' ', `pn`.`middle_name`, ' '), ' '),
              `pn`.`family_name`)                                          AS `patient_name`,
       (case `p`.`gender` when 'M' then 'MALE' when 'F' then 'FEMALE' end) AS `sex`,
       `p`.`birthdate`                                                     AS `birthdate`,
       `pi`.`identifier`                                                   AS `patient_identifier`,
       `v`.`visit_id`                                                      AS `visit_id`,
       `vt`.`name`                                                         AS `visit_type_name`,
       `v`.`date_started`                                                  AS `visit_date_started`,
       `v`.`date_stopped`                                                  AS `visit_date_stopped`,
       if((`v`.`voided` = 0), 'VALID', 'INVALID')                          AS `visit_validity`,
       concat(`pn_visit_creator`.`given_name`,
              if((`pn_visit_creator`.`middle_name` is not null), concat(' ', `pn_visit_creator`.`middle_name`, ' '),
                 ' '), `pn_visit_creator`.`family_name`)                   AS `visit_creator`,
       `pn_visit_creator`.`person_id`                                      AS `visit_creator_id`,
       concat(`pn_patient_creator`.`given_name`,
              if((`pn_patient_creator`.`middle_name` is not null), concat(' ', `pn_patient_creator`.`middle_name`, ' '),
                 ' '), `pn_patient_creator`.`family_name`)                 AS `patient_creator`,
       `pn_patient_creator`.`person_id`                                    AS `patient_creator_id`,
       `v`.`uuid`                                                          AS `visit_uuid`,
       `p`.`uuid`                                                          AS `patient_uuid`
from (((((((((`openmrs`.`patient` `pt` join `openmrs`.`person` `p` on ((`pt`.`patient_id` = `p`.`person_id`))) join `openmrs`.`person_name` `pn` on ((`pn`.`person_id` = `pt`.`patient_id`))) join `openmrs`.`patient_identifier` `pi` on ((
        (`pi`.`patient_id` = `pt`.`patient_id`) and
        (`pi`.`identifier_type` = 3)))) left join `openmrs`.`visit` `v` on ((`pt`.`patient_id` = `v`.`patient_id`))) left join `openmrs`.`visit_type` `vt` on ((`v`.`visit_type_id` = `vt`.`visit_type_id`))) left join `openmrs`.`users` `u_visit_creator` on ((`v`.`creator` = `u_visit_creator`.`user_id`))) left join `openmrs`.`person_name` `pn_visit_creator` on ((`pn_visit_creator`.`person_id` = `u_visit_creator`.`person_id`))) left join `openmrs`.`users` `u_patient_creator` on ((`p`.`creator` = `u_patient_creator`.`user_id`)))
         left join `openmrs`.`person_name` `pn_patient_creator`
                   on ((`pn_patient_creator`.`person_id` = `u_patient_creator`.`person_id`)));

