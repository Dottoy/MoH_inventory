create definer = root@localhost view ctc_concept_order as
select `cv`.`concept_id`                                                 AS `name`,
       group_concat(`cv`.`concept_full_name` separator ', ')             AS `value`,
       (to_days(`o`.`auto_expire_date`) - to_days(`o`.`date_activated`)) AS `dispenseDays`,
       `o`.`encounter_id`                                                AS `encounter_id`
from ((`openmrs`.`orders` `o` join `openmrs`.`concept_view` `cv` on (((`cv`.`concept_id` = `o`.`concept_id`) and (`o`.`voided` = 0))))
         left join `openmrs`.`concept_view` `answer_concept` on ((`answer_concept`.`concept_id` = `o`.`concept_id`)))
where `cv`.`concept_full_name` in (select `concept_view`.`concept_full_name`
                                   from `openmrs`.`concept_view`
                                   where (`concept_view`.`concept_class_name` = 'Drug'))
group by `o`.`encounter_id`;

