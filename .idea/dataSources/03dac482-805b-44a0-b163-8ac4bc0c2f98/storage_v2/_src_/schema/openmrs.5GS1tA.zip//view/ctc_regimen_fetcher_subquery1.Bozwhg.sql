create definer = root@localhost view ctc_regimen_fetcher_subquery1 as
select 1 AS `count`, 1 AS `order_set_id`;

