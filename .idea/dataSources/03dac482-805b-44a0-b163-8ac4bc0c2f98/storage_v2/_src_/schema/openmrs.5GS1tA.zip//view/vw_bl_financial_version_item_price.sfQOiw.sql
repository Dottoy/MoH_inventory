create definer = root@localhost view vw_bl_financial_version_item_price as
(select `bfp`.`period_id`                                                                               AS `financial_period_id`,
        `bfp`.`name`                                                                                    AS `financial_period_name`,
        if((`bfp`.`period_id` is not null), if((`bfp`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `financial_period_status`,
        `bplv`.`list_id`                                                                                AS `price_list_version_id`,
        `bplv`.`version_name`                                                                           AS `version_name`,
        if((`bplv`.`list_id` is not null), if((`bplv`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `price_list_status`,
        `bip`.`item_price_id`                                                                           AS `item_price_id`,
        if((`bip`.`item_price_id` is not null), if((`bip`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `item_price_status`,
        `pi`.`item_id`                                                                                  AS `item_id`,
        `pi`.`name`                                                                                     AS `item_name`,
        `bst`.`service_type_id`                                                                         AS `service_type_id`,
        `bst`.`name`                                                                                    AS `service_type_name`,
        `cn_payment_category`.`concept_id`                                                              AS `payment_category_id`,
        `cn_payment_sub_category`.`concept_id`                                                          AS `payment_sub_category_id`,
        `cn_payment_category`.`name`                                                                    AS `payment_category`,
        `cn_payment_sub_category`.`name`                                                                AS `payment_sub_category`,
        `bip`.`selling_price`                                                                           AS `selling_price`
 from ((((((((`openmrs`.`ph_item` `pi` left join `openmrs`.`bl_item_price` `bip` on (((`pi`.`item_id` = `bip`.`item`) and (`bip`.`service_type` = 3)))) left join `openmrs`.`bl_price_list_version` `bplv` on ((`bip`.`price_list_version` = `bplv`.`list_id`))) left join `openmrs`.`bl_financial_period` `bfp` on ((`bplv`.`financial_period` = `bfp`.`period_id`))) left join `openmrs`.`bl_service_type` `bst` on ((`bip`.`service_type` = `bst`.`service_type_id`))) left join `openmrs`.`concept` `c_payment_category` on ((`c_payment_category`.`concept_id` = `bip`.`payment_category`))) left join `openmrs`.`concept_name` `cn_payment_category` on ((
         (`cn_payment_category`.`concept_id` = `bip`.`payment_category`) and
         (`cn_payment_category`.`concept_name_type` = 'FULLY_SPECIFIED')))) left join `openmrs`.`concept` `c_payment_sub_category` on ((`c_payment_sub_category`.`concept_id` = `bip`.`payment_sub_category`)))
          left join `openmrs`.`concept_name` `cn_payment_sub_category`
                    on (((`cn_payment_sub_category`.`concept_id` = `bip`.`payment_sub_category`) and
                         (`cn_payment_sub_category`.`concept_name_type` = 'FULLY_SPECIFIED')))))
union all
(select `bfp`.`period_id`                                                                               AS `financial_period_id`,
        `bfp`.`name`                                                                                    AS `financial_period_name`,
        if((`bfp`.`period_id` is not null), if((`bfp`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `financial_period_status`,
        `bplv`.`list_id`                                                                                AS `price_list_version_id`,
        `bplv`.`version_name`                                                                           AS `version_name`,
        if((`bplv`.`list_id` is not null), if((`bplv`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `price_list_status`,
        `bip`.`item_price_id`                                                                           AS `item_price_id`,
        if((`bip`.`item_price_id` is not null), if((`bip`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `item_price_status`,
        `invi`.`item_id`                                                                                AS `item_id`,
        `invi`.`name`                                                                                   AS `item_name`,
        `bst`.`service_type_id`                                                                         AS `service_type_id`,
        `bst`.`name`                                                                                    AS `service_type_name`,
        `cn_payment_category`.`concept_id`                                                              AS `payment_category_id`,
        `cn_payment_sub_category`.`concept_id`                                                          AS `payment_sub_category_id`,
        `cn_payment_category`.`name`                                                                    AS `payment_category`,
        `cn_payment_sub_category`.`name`                                                                AS `payment_sub_category`,
        `bip`.`selling_price`                                                                           AS `selling_price`
 from ((((((((`openmrs`.`inv_item` `invi` left join `openmrs`.`bl_item_price` `bip` on (((`invi`.`item_id` = `bip`.`item`) and (`bip`.`service_type` = 3)))) left join `openmrs`.`bl_price_list_version` `bplv` on ((`bip`.`price_list_version` = `bplv`.`list_id`))) left join `openmrs`.`bl_financial_period` `bfp` on ((`bplv`.`financial_period` = `bfp`.`period_id`))) left join `openmrs`.`bl_service_type` `bst` on ((`bip`.`service_type` = `bst`.`service_type_id`))) left join `openmrs`.`concept` `c_payment_category` on ((`c_payment_category`.`concept_id` = `bip`.`payment_category`))) left join `openmrs`.`concept_name` `cn_payment_category` on ((
         (`cn_payment_category`.`concept_id` = `bip`.`payment_category`) and
         (`cn_payment_category`.`concept_name_type` = 'FULLY_SPECIFIED')))) left join `openmrs`.`concept` `c_payment_sub_category` on ((`c_payment_sub_category`.`concept_id` = `bip`.`payment_sub_category`)))
          left join `openmrs`.`concept_name` `cn_payment_sub_category`
                    on (((`cn_payment_sub_category`.`concept_id` = `bip`.`payment_sub_category`) and
                         (`cn_payment_sub_category`.`concept_name_type` = 'FULLY_SPECIFIED')))))
union all
(select `bfp`.`period_id`                                                                               AS `financial_period_id`,
        `bfp`.`name`                                                                                    AS `financial_period_name`,
        if((`bfp`.`period_id` is not null), if((`bfp`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `financial_period_status`,
        `bplv`.`list_id`                                                                                AS `price_list_version_id`,
        `bplv`.`version_name`                                                                           AS `version_name`,
        if((`bplv`.`list_id` is not null), if((`bplv`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `price_list_status`,
        `bip`.`item_price_id`                                                                           AS `item_price_id`,
        if((`bip`.`item_price_id` is not null), if((`bip`.`retired` = 0), 'ACTIVE', 'INACTIVE'),
           'N/A')                                                                                       AS `item_price_status`,
        `cn_item`.`concept_id`                                                                          AS `item_id`,
        `cn_item`.`name`                                                                                AS `item_name`,
        `bst`.`service_type_id`                                                                         AS `service_type_id`,
        `bst`.`name`                                                                                    AS `service_type_name`,
        `cn_payment_category`.`concept_id`                                                              AS `payment_category_id`,
        `cn_payment_sub_category`.`concept_id`                                                          AS `payment_sub_category_id`,
        `cn_payment_category`.`name`                                                                    AS `payment_category`,
        `cn_payment_sub_category`.`name`                                                                AS `payment_sub_category`,
        `bip`.`selling_price`                                                                           AS `selling_price`
 from (((((((((`openmrs`.`concept` `c` join `openmrs`.`bl_item_price` `bip` on (((`c`.`concept_id` = `bip`.`item`) and
                                                                                 (`bip`.`service_type` in (1, 2, 4, 5))))) left join `openmrs`.`bl_price_list_version` `bplv` on ((`bip`.`price_list_version` = `bplv`.`list_id`))) left join `openmrs`.`bl_financial_period` `bfp` on ((`bplv`.`financial_period` = `bfp`.`period_id`))) left join `openmrs`.`bl_service_type` `bst` on ((`bip`.`service_type` = `bst`.`service_type_id`))) left join `openmrs`.`concept_name` `cn_item` on ((
         (`cn_item`.`concept_id` = `bip`.`item`) and
         (`cn_item`.`concept_name_type` = 'FULLY_SPECIFIED')))) left join `openmrs`.`concept` `c_payment_category` on ((`c_payment_category`.`concept_id` = `bip`.`payment_category`))) left join `openmrs`.`concept_name` `cn_payment_category` on ((
         (`cn_payment_category`.`concept_id` = `bip`.`payment_category`) and
         (`cn_payment_category`.`concept_name_type` = 'FULLY_SPECIFIED')))) left join `openmrs`.`concept` `c_payment_sub_category` on ((`c_payment_sub_category`.`concept_id` = `bip`.`payment_sub_category`)))
          left join `openmrs`.`concept_name` `cn_payment_sub_category`
                    on (((`cn_payment_sub_category`.`concept_id` = `bip`.`payment_sub_category`) and
                         (`cn_payment_sub_category`.`concept_name_type` = 'FULLY_SPECIFIED')))));

