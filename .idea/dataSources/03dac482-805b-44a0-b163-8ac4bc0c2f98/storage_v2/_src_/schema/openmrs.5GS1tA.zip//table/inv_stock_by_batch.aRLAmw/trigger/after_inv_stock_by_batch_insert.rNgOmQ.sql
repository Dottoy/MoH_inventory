create definer = `openmrs-user`@localhost trigger after_inv_stock_by_batch_insert
    after insert
    on inv_stock_by_batch
    for each row
BEGIN
    DECLARE itm INTEGER;
    DECLARE itemHandStock DOUBLE;
    DECLARE totalItemQty DOUBLE;

    SET itm := (SELECT itb.item
                FROM inv_item_batch itb
                WHERE itb.batch_reference_id = NEW.batch);

    SET totalItemQty := (SELECT SUM(isbb.quantity)
                         FROM inv_stock_by_batch isbb
                         WHERE isbb.store = NEW.store
                           AND isbb.batch IN (SELECT itb.batch_reference_id
                                              FROM inv_item_batch itb
                                              WHERE itb.item = itm));

    SET itemHandStock :=
            (SELECT isoh2.quantity FROM inv_stock_on_hand isoh2 WHERE isoh2.item = itm and isoh2.store = NEW.store);

    IF itemHandStock IS NULL THEN
        INSERT INTO inv_stock_on_hand (item, store, quantity, creator, date_created, uuid)
        VALUES (itm, NEW.store, totalItemQty, NEW.creator, now(), uuid());
    ELSEIF itemHandStock >= 0 THEN
        UPDATE inv_stock_on_hand isoh
        SET isoh.quantity     = totalItemQty,
            isoh.date_changed = now(),
            isoh.changed_by   = NEW.changed_by
        WHERE isoh.item = itm
          AND isoh.store = NEW.store;
    END IF;
END;

