create definer = `openmrs-user`@localhost trigger after_bl_sale_quote_line_insert
    after insert
    on bl_sale_quote_line
    for each row
begin
                declare rows int;
                declare totalQuoteAmount double;
                declare totalPayableAmount double;
                SET rows=(select count(*) from bl_sale_quote bsq where bsq.quote_id=NEW.sale_quote);
                    if rows > 0 then
                        SET totalQuoteAmount = (select sum(quoted_amount) from bl_sale_quote_line bsql where bsql.sale_quote = NEW.sale_quote and bsql.status < 7 );
                        SET totalPayableAmount = (select sum(payable_amount) from bl_sale_quote_line bsql where bsql.sale_quote = NEW.sale_quote and bsql.status < 7);
                        update bl_sale_quote set total_quote = totalQuoteAmount, payable_amount = totalPayableAmount where quote_id = NEW.sale_quote;
                    end if;
            end;

