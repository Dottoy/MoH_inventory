create definer = `openmrs-user`@localhost trigger after_ph_item_request_insert
    after insert
    on ph_item_request
    for each row
begin
        declare rows int;
        SET rows=(select count(*) from ph_item_request_status_log pirsl where(pirsl.request_id=NEW.request_id));
        if rows=0 then
            insert into ph_item_request_status_log(request_id,status_id,creator,date_created,uuid) values(NEW.request_id,NEW.status_code,NEW.creator,now(),uuid());
        end if;
        end;

