create definer = `openmrs-user`@localhost trigger after_ph_item_stock_by_batch_insert
    after insert
    on ph_item_stock_by_batch
    for each row
begin
            declare rows int;
            declare quantity_to_update int;
            declare transaction_hack_uuid varchar(80);
            declare transaction_src_uuid varchar(80);
            declare transaction_uuid varchar(80);
            declare transaction_creator_id int;
            declare prescripxn_order int;
            declare transacxn_id int;
            declare transaction_src_id int;
            declare completed int;

            SET transaction_hack_uuid = NEW.latest_transaction_map;
            SET transaction_uuid = uuid();
            SET rows=(select count(*) from ph_item_stock_on_hand pisoh where(pisoh.store_id=NEW.store_id and pisoh.item_id=NEW.item_id));
            SET transaction_src_uuid = (select pitmh1.latest_transaction_source_uuid from ph_item_transaction_map_hack pitmh1 where pitmh1.entry_uuid = transaction_hack_uuid);
            SET transaction_src_id = (select pits.transaction_source_id from ph_item_transaction_source pits where pits.uuid = transaction_src_uuid);
            SET transaction_creator_id = (select pitmh2.creator from ph_item_transaction_map_hack pitmh2 where pitmh2.entry_uuid = transaction_hack_uuid);
            SET completed = (select pitmh2.completed from ph_item_transaction_map_hack pitmh2 where pitmh2.entry_uuid = transaction_hack_uuid);

            if rows=0 then
            insert into ph_item_stock_on_hand(store_id,item_id,quantity,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.quantity,transaction_creator_id,now(),uuid());
            if transaction_src_id is not null and transaction_src_id > 0 then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid)
            values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.quantity,'0',NEW.quantity,'1',transaction_src_id,transaction_creator_id,now(),transaction_uuid);
            end if;
            if transaction_src_id is null then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid)
            values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.quantity,'0',NEW.quantity,'1','0',transaction_creator_id,now(),transaction_uuid);
            end if;

            SET transacxn_id = (select pitX.transaction_id from ph_item_transaction pitX where pitX.uuid = transaction_uuid);
            SET prescripxn_order = (select pitmh3.prescription_order from ph_item_transaction_map_hack pitmh3 where pitmh3.entry_uuid = transaction_hack_uuid);

            if transacxn_id > 0 then
            if transaction_src_uuid = '4ba23772-329b-4fc6-a8cd-f33d5596c8bc' and prescripxn_order > 0 then
            insert into ph_item_transaction_dispense (transaction_id, prescription_order) values(transacxn_id,prescripxn_order);
            end if;
            if completed = 1 then
            delete from ph_item_transaction_map_hack where entry_uuid = transaction_hack_uuid;
            end if;
            end if;
            end if;
            if rows > 0 then
            SET quantity_to_update=(select sum(pisbb.quantity) from ph_item_stock_by_batch pisbb where(pisbb.store_id=NEW.store_id and pisbb.item_id=NEW.item_id));
            update ph_item_stock_on_hand pisoh set pisoh.quantity=quantity_to_update,pisoh.date_changed=now(),pisoh.changed_by=transaction_creator_id where(pisoh.store_id=NEW.store_id and pisoh.item_id=NEW.item_id);

            if transaction_src_id is not null and transaction_src_id > 0 then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.quantity,(quantity_to_update-NEW.quantity),quantity_to_update,'1',transaction_src_id,transaction_creator_id,now(),transaction_uuid);
            end if;
            if transaction_src_id is null then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.quantity,(quantity_to_update-NEW.quantity),quantity_to_update,'1','0',transaction_creator_id,now(),transaction_uuid);
            end if;

            SET transacxn_id = (select transaction_id from ph_item_transaction where uuid = transaction_uuid);
            SET prescripxn_order = (select pitmhX.prescription_order from ph_item_transaction_map_hack pitmhX where pitmhX.entry_uuid = transaction_hack_uuid);

            if transacxn_id > 0 then
            if transaction_src_uuid = '4ba23772-329b-4fc6-a8cd-f33d5596c8bc' and prescripxn_order > 0 then
            insert into ph_item_transaction_dispense (transaction_id, prescription_order) values(transaction_id,prescripxn_order);
            end if;
            if completed = 1 then
            delete from ph_item_transaction_map_hack where entry_uuid = transaction_hack_uuid;
            end if;
            end if;
            end if;
            end;

