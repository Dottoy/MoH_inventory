create definer = root@localhost view vw_bl_order_pay_installment_cleaned as
select `bpi`.`soql_no`      AS `soql_no`,
       `bpi`.`receipt`      AS `receipt`,
       `bpi`.`received_by`  AS `received_by`,
       `bpi`.`date_created` AS `date_created`
from (`openmrs`.`bl_order_pay_installment` `bpi`
         join `openmrs`.`vw_bl_order_pay_installment_unique` `vbopiu` on ((`bpi`.`entry_no` = `vbopiu`.`entry_no`)));

