create definer = root@localhost view tb_reg_conc as
select `ppa`.`attribute_type_id`  AS `attrid`,
       `pat`.`name`               AS `name`,
       `ppa`.`value_reference`    AS `value`,
       `ppa`.`patient_program_id` AS `patient_program_id`
from (`openmrs`.`patient_program_attribute` `ppa`
         left join `openmrs`.`program_attribute_type` `pat`
                   on ((`pat`.`program_attribute_type_id` = `ppa`.`attribute_type_id`)))
where (`pat`.`name` in
       ('District Registration Number', 'Place of Work', 'Place of Work-Other', 'Reffered by', 'Reffered by-Other',
        'DOT Option', 'Name of Treatment Supporter', 'Tel No of Treatment Supporter',
        'Physical Address of Treatment Supporter', 'Name of Community Support Organisation', 'Classification by site',
        'Site', 'Classification by History of Treatment', 'HIV Status', 'HIV Care registration number', 'CPT',
        'CPT Start Date', 'ART drugs', 'ART Start Date'));

