create definer = root@localhost view vw_bl_patient_visit_quote_discount as
select `vbpvq`.`patient`                                 AS `patient`,
       `vbpvq`.`patient_name`                            AS `patient_name`,
       `vbpvq`.`sex`                                     AS `sex`,
       `vbpvq`.`birthdate`                               AS `birthdate`,
       `vbpvq`.`patient_identifier`                      AS `patient_identifier`,
       `vbpvq`.`patient_uuid`                            AS `patient_uuid`,
       `vbpvq`.`patient_creator`                         AS `patient_creator`,
       `vbpvq`.`visit`                                   AS `visit`,
       `vbpvq`.`visit_type`                              AS `visit_type`,
       `vbpvq`.`visit_start_date`                        AS `visit_start_date`,
       `vbpvq`.`visit_stop_date`                         AS `visit_stop_date`,
       `vbpvq`.`visit_validity`                          AS `visit_validity`,
       `vbpvq`.`visit_creator`                           AS `visit_creator`,
       `vbpvq`.`visit_uuid`                              AS `visit_uuid`,
       `vbpvq`.`sale_quote_id`                           AS `sale_quote_id`,
       `vbpvq`.`main_quote_status`                       AS `main_quote_status`,
       `vbpvq`.`payment_category_id`                     AS `payment_category_id`,
       `vbpvq`.`payment_sub_category_id`                 AS `payment_sub_category_id`,
       `vbpvq`.`payment_category`                        AS `payment_category`,
       `vbpvq`.`payment_sub_category`                    AS `payment_sub_category`,
       `vbpvq`.`service_type_id`                         AS `service_type_id`,
       `vbpvq`.`service_type_name`                       AS `service_type_name`,
       `vbpvq`.`item_id`                                 AS `item_id`,
       `vbpvq`.`item_name`                               AS `item_name`,
       `vbpvq`.`unit_price`                              AS `unit_price`,
       `vbpvq`.`items_quantity`                          AS `items_quantity`,
       `vbpvq`.`units`                                   AS `units`,
       `vbpvq`.`quoted_amount`                           AS `quoted_amount`,
       `vbpvq`.`payable_amount`                          AS `payable_amount`,
       `vbpvq`.`quote_line_status`                       AS `quote_line_status`,
       `vbpvq`.`date_quoted`                             AS `date_quoted`,
       if((`bd`.`discount_id` is not null), 'YES', 'NO') AS `discounted`,
       `bd`.`discount_id`                                AS `discount_number`,
       `bd`.`proposed_discount_amount`                   AS `proposed_discount_amount`,
       `bd`.`date_created`                               AS `date_discount_proposed`,
       `pn_discount_proposer`.`person_id`                AS `discount_proposer_id`,
       concat(`pn_discount_proposer`.`given_name`, if((`pn_discount_proposer`.`middle_name` is not null),
                                                      concat(' ', `pn_discount_proposer`.`middle_name`, ' '), ' '),
              `pn_discount_proposer`.`family_name`)      AS `discount_proposer`,
       `bd`.`approved_discount_amount`                   AS `approved_discount_amount`,
       `pn_discount_approver`.`person_id`                AS `discount_approver_id`,
       concat(`pn_discount_approver`.`given_name`, if((`pn_discount_approver`.`middle_name` is not null),
                                                      concat(' ', `pn_discount_approver`.`middle_name`, ' '), ' '),
              `pn_discount_approver`.`family_name`)      AS `discount_approver`,
       `bd`.`date_approved`                              AS `date_discount_approved`,
       `bdc`.`criteria_no`                               AS `discount_criteria_id`,
       `bdc`.`name`                                      AS `discount_criteria`
from ((((((`openmrs`.`bl_discount` `bd` left join `openmrs`.`vw_bl_patient_visit_quote` `vbpvq`
           on ((`vbpvq`.`quote_line_id` = `bd`.`quote_line`))) left join `openmrs`.`bl_discount_criteria` `bdc`
          on ((`bd`.`discount_criteria` = `bdc`.`criteria_no`))) left join `openmrs`.`users` `u_discount_proposer`
         on ((`u_discount_proposer`.`user_id` = `bd`.`initiated_by`))) left join `openmrs`.`person_name` `pn_discount_proposer`
        on ((`pn_discount_proposer`.`person_id` = `u_discount_proposer`.`person_id`))) left join `openmrs`.`users` `u_discount_approver`
       on ((`u_discount_approver`.`user_id` = `bd`.`approved_by`))) left join `openmrs`.`person_name` `pn_discount_approver`
      on ((`pn_discount_approver`.`person_id` = `u_discount_approver`.`person_id`)))
where (`vbpvq`.`item_id` is not null);

