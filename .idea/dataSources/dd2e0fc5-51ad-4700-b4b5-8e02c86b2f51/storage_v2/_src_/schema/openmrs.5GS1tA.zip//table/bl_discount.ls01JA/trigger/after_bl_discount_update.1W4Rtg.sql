create definer = `openmrs-user`@localhost trigger after_bl_discount_update
    after update
    on bl_discount
    for each row
begin
                declare rows int;
                declare quotedAmount double;
                declare approvedAmount double;
                declare payableAmount double;
                SET rows=(select count(*) from bl_sale_quote_line bsql where bsql.quote_line_id=OLD.quote_line);
                SET quotedAmount = (select quoted_amount from bl_sale_quote_line bsql where bsql.quote_line_id=OLD.quote_line);
                SET approvedAmount = (select approved_discount_amount from bl_discount bd where bd.quote_line=OLD.quote_line);
                SET payableAmount = (quotedAmount-approvedAmount);
                if payableAmount < 0 then
                    SET payableAmount = 0;
                end if;
                update bl_sale_quote_line set payable_amount=payableAmount where quote_line_id = OLD.quote_line;
            end;

