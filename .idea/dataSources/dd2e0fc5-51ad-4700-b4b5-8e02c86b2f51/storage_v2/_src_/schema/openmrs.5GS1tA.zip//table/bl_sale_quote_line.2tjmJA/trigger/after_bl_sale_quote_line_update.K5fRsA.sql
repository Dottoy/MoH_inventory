create definer = `openmrs-user`@localhost trigger after_bl_sale_quote_line_update
    after update
    on bl_sale_quote_line
    for each row
begin
                declare rows int;
                declare new int;
                declare confirmed int;
                declare cancelled int;
                declare totalQuoteAmount double;
                declare totalPayableAmount double;
                SET rows=(select count(*) from bl_sale_quote bsq where bsq.quote_id=OLD.sale_quote );
                if rows > 0 then
                    SET totalQuoteAmount = (select sum(quoted_amount) from bl_sale_quote_line bsql where bsql.sale_quote = OLD.sale_quote and bsql.status < 7);
                    SET totalPayableAmount = (select sum(payable_amount) from bl_sale_quote_line bsql where bsql.sale_quote = OLD.sale_quote and bsql.status < 7);
                    update bl_sale_quote set total_quote = ifnull(totalQuoteAmount,0), payable_amount = ifnull(totalPayableAmount,0) where quote_id = OLD.sale_quote;
                end if;

                SET new = (select count(*) from bl_sale_quote_line where sale_quote = OLD.sale_quote and status = 5);
                SET confirmed = (select count(*) from bl_sale_quote_line where sale_quote = OLD.sale_quote and  status = 6);
                SET cancelled = (select count(*) from bl_sale_quote_line where sale_quote = OLD.sale_quote and  status = 7);
                if new > 0 and confirmed > 0 then
                    update bl_sale_quote set status = 2 where quote_id = OLD.sale_quote;
                end if;
                if new = 0 and confirmed > 0 then
                    update bl_sale_quote set status = 3 where quote_id = OLD.sale_quote;
                end if;
                if new = 0 and confirmed = 0 and cancelled > 0 then
                    update bl_sale_quote set status = 4 where quote_id = OLD.sale_quote;
                end if;
                if new > 0 and confirmed = 0 and cancelled > 0 then
                    update bl_sale_quote set status = 1 where quote_id = OLD.sale_quote;
                end if;
            end;

