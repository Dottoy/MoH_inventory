create definer = `openmrs-user`@localhost trigger after_bl_sale_order_by_quote_line_update
    after update
    on bl_sale_order_by_quote_line
    for each row
begin
            declare rows int;
            declare payableAmountQuote double;
            declare totalDebt double;
            declare totalPaidAmount double;
            if NEW.paid_amount <> OLD.paid_amount then
                SET totalPaidAmount = (select sum(paid_amount) from bl_sale_order_by_quote_line where sale_order_quote = OLD.sale_order_quote);
                SET totalDebt = (select sum(debt_amount) from bl_sale_order_by_quote_line where sale_order_quote = OLD.sale_order_quote);
                update bl_sale_order_by_quote set paid_amount = totalPaidAmount, debt_amount = totalDebt where soq_no = OLD.sale_order_quote;
            end if;
            end;

