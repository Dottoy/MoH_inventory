create definer = `openmrs-user`@localhost trigger after_ph_item_ledger_insert
    after insert
    on ph_item_ledger
    for each row
begin
    declare quantity_to_update double;
    declare quantity_current double;
    declare rows int;
    declare ledgerType char(58);
    SET rows=(select count(*) from ph_item_stock_by_batch pisbb where(pisbb.store_id=NEW.store_id and pisbb.item_id=NEW.item_id and pisbb.batch_no=NEW.batch_no));
    SET ledgerType=(select pilt.operation from ph_item_ledger pil inner join ph_item_ledger_type pilt on pil.ledger_type =pilt.ledger_type_id where pil.ledger_entry_id=NEW.ledger_entry_id);
    case
    when ledgerType = '+ve' then
    if rows > 0 then
    update ph_item_stock_by_batch pisbb set pisbb.latest_transaction_map = NEW.uuid, pisbb.quantity=pisbb.quantity+NEW.quantity,pisbb.date_changed=now(),pisbb.changed_by=NEW.changed_by where(pisbb.store_id=NEW.store_id and pisbb.item_id=NEW.item_id and pisbb.batch_no=NEW.batch_no);
    end if;
    if rows=0 then
    insert into ph_item_stock_by_batch(store_id,item_id,batch_no,latest_transaction_map,quantity,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.uuid,NEW.quantity,NEW.creator,now(),uuid());
    end if;
    when ledgerType = '-ve' then
    if rows > 0 then
    SET quantity_current=(select pisbb.quantity from ph_item_stock_by_batch pisbb where(pisbb.store_id=NEW.store_id and pisbb.item_id=NEW.item_id and pisbb.batch_no=NEW.batch_no));
    SET quantity_to_update=quantity_current-NEW.quantity;
    if (quantity_to_update > 0) then
    SET quantity_to_update=0;
    end if;
    update ph_item_stock_by_batch pisbb set pisbb.latest_transaction_map = NEW.uuid, pisbb.quantity=quantity_to_update,pisbb.date_changed=now(),pisbb.changed_by=NEW.changed_by where(pisbb.store_id=NEW.store_id and pisbb.item_id=NEW.item_id and pisbb.batch_no=NEW.batch_no);
    end if;
    end case;
    end;

