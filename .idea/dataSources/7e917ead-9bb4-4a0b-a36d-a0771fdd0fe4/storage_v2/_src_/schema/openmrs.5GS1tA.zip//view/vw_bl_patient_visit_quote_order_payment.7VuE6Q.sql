create definer = root@localhost view vw_bl_patient_visit_quote_order_payment as
select `vbpvq`.`patient`                                                            AS `patient`,
       `vbpvq`.`patient_name`                                                       AS `patient_name`,
       `vbpvq`.`sex`                                                                AS `sex`,
       `vbpvq`.`birthdate`                                                          AS `birthdate`,
       `vbpvq`.`patient_identifier`                                                 AS `patient_identifier`,
       `vbpvq`.`patient_uuid`                                                       AS `patient_uuid`,
       `vbpvq`.`patient_creator`                                                    AS `patient_creator`,
       `vbpvq`.`visit`                                                              AS `visit`,
       `vbpvq`.`visit_type`                                                         AS `visit_type`,
       `vbpvq`.`visit_start_date`                                                   AS `visit_start_date`,
       `vbpvq`.`visit_stop_date`                                                    AS `visit_stop_date`,
       `vbpvq`.`visit_validity`                                                     AS `visit_validity`,
       `vbpvq`.`visit_creator`                                                      AS `visit_creator`,
       `vbpvq`.`visit_uuid`                                                         AS `visit_uuid`,
       `vbpvq`.`sale_quote_id`                                                      AS `sale_quote_id`,
       `bsobq`.`date_created`                                                       AS `sale_date_created`,
       `vbpvq`.`main_quote_status`                                                  AS `main_quote_status`,
       `vbpvq`.`quote_line_status`                                                  AS `quote_line_status`,
       `bsobq`.`soq_no`                                                             AS `sale_order_id`,
       `bsobq`.`dated_sale_id`                                                      AS `dated_order_id`,
       concat(`pn_order_confirmer`.`given_name`,
              if((`pn_order_confirmer`.`middle_name` is not null), concat(' ', `pn_order_confirmer`.`middle_name`, ' '),
                 ' '), `pn_order_confirmer`.`family_name`)                          AS `order_confirmed_by`,
       `pn_order_confirmer`.`person_id`                                             AS `order_confirmer_id`,
       `vbpvq`.`payment_category_id`                                                AS `payment_category_id`,
       `vbpvq`.`payment_sub_category_id`                                            AS `payment_sub_category_id`,
       `vbpvq`.`payment_category`                                                   AS `payment_category`,
       `vbpvq`.`payment_sub_category`                                               AS `payment_sub_category`,
       `vbpvq`.`service_type_id`                                                    AS `service_type_id`,
       `vbpvq`.`service_type_name`                                                  AS `service_type_name`,
       `vbpvq`.`item_id`                                                            AS `item_id`,
       `vbpvq`.`item_name`                                                          AS `item_name`,
       `vbpvq`.`unit_price`                                                         AS `unit_price`,
       `vbpvq`.`items_quantity`                                                     AS `items_quantity`,
       `vbpvq`.`units`                                                              AS `units`,
       `vbpvq`.`quoted_amount`                                                      AS `quoted_amount`,
       `vbpvq`.`payable_amount`                                                     AS `payable_amount`,
       `bsobql`.`paid_amount`                                                       AS `paid_amount`,
       ucase(`bsobq`.`payment_method`)                                              AS `payment_method`,
       if((ucase(`bsobq`.`payment_method`) = 'GEPG'), `bg`.`control_number`, 'N/A') AS `control_number`,
       `vbopic`.`receipt`                                                           AS `receipt_number`,
       `vbopic`.`date_created`                                                      AS `payment_datetime`,
       concat(`pn_payment_receiver`.`given_name`, if((`pn_payment_receiver`.`middle_name` is not null),
                                                     concat(' ', `pn_payment_receiver`.`middle_name`, ' '), ' '),
              `pn_payment_receiver`.`family_name`)                                  AS `payment_receiver`,
       `pn_payment_receiver`.`person_id`                                            AS `payment_receiver_id`
from ((((((((((`openmrs`.`bl_sale_order_by_quote` `bsobq` left join `openmrs`.`bl_sale_quote` `bsq`
               on ((`bsobq`.`sale_quote` = `bsq`.`quote_id`))) left join `openmrs`.`bl_sale_order_by_quote_line` `bsobql`
              on ((`bsobq`.`soq_no` = `bsobql`.`sale_order_quote`))) left join `openmrs`.`vw_bl_patient_visit_quote` `vbpvq`
             on ((`vbpvq`.`quote_line_id` = `bsobql`.`quote_line`))) left join `openmrs`.`bl_sale_quote_reference_map` `bsqrm`
            on ((`bsobql`.`quote_line` = `bsqrm`.`sale_quote_line`))) left join `openmrs`.`vw_bl_order_pay_installment_cleaned` `vbopic`
           on ((`bsobql`.`soql_no` = `vbopic`.`soql_no`))) left join `openmrs`.`bl_gepg` `bg`
          on ((`bsobq`.`dated_sale_id` = `bg`.`dated_sale_no`))) left join `openmrs`.`users` `u_order_confirmer`
         on ((`u_order_confirmer`.`user_id` = `bsobq`.`creator`))) left join `openmrs`.`person_name` `pn_order_confirmer`
        on ((`pn_order_confirmer`.`person_id` = `u_order_confirmer`.`person_id`))) left join `openmrs`.`users` `u_payment_receiver`
       on ((`u_payment_receiver`.`user_id` = `vbopic`.`received_by`))) left join `openmrs`.`person_name` `pn_payment_receiver`
      on ((`pn_payment_receiver`.`person_id` = `u_payment_receiver`.`person_id`)))
where (`vbpvq`.`item_id` is not null);

