create definer = root@localhost view ctc_visit_form as
select `pi`.`identifier`                                                                       AS `PatientID`,
       `attr`.`value_reference`                                                                AS `CTCID`,
       concat(`pn`.`given_name`, ' ', `pn`.`family_name`)                                      AS `PatientName`,
       floor(((to_days(curdate()) - to_days(`p`.`birthdate`)) / 365))                          AS `AgeToDate`,
       `p`.`gender`                                                                            AS `Gender`,
       `v`.`date_started`                                                                      AS `visitStartDate`,
       (select `openmrs`.`patient_program`.`date_enrolled`
        from `openmrs`.`patient_program`
        where (`openmrs`.`patient_program`.`patient_program_id` = `pp`.`patient_program_id`))  AS `EnrollmentDate`,
       `v`.`date_started`                                                                      AS `VisitDate`,
       max(if((`conp`.`name` = 3329), `conp`.`value`, NULL))                                   AS `VisitTypeCode`,
       max(if((`conp`.`name` = 2254), `conp`.`value`, NULL))                                   AS `ViralLoad`,
       max(if((`conp`.`name` = 'Weight'), `conp`.`value`, NULL))                               AS `Weight`,
       max(if((`conp`.`name` = 'Height'), `conp`.`value`, NULL))                               AS `Height`,
       max(if((`conp`.`name` = '	CTC - WHO clinical stage (1 - 4)'), `conp`.`value`, NULL)) AS `WHOStage`,
       max(if((`conp`.`name` = 3649), `conp`.`value`, NULL))                                   AS `CD4Percentage`,
       max(if((`conp`.`name` = 1187), `conp`.`value`, NULL))                                   AS `CD4Count`,
       max(if((`conp`.`name` = 'Signs and Symptoms and OIs'), `conp`.`value`, NULL))           AS `SignsAndSymptoms`,
       max(if((`conp`.`name` = 'CTC - Other Signs Symptoms and OIs'), `conp`.`value`,
              NULL))                                                                           AS `OtherSignsAndSymptoms`,
       max(if((`conp`.`name` = 'CTC - Functional Status'), `conp`.`value`, NULL))              AS `FunctionalStatus`,
       max(if((`conp`.`name` = 'CTC - Pregnant Y/N'), `conp`.`value`, NULL))                   AS `PregnancyStatus`,
       max(if((`conp`.`name` = 'CTC - EDD'), `conp`.`value`, NULL))                            AS `EDD`,
       max(if((`conp`.`name` = 'CTC - ANC Number'), `conp`.`value`, NULL))                     AS `ANCNumber`,
       max(if((`conp`.`name` = 'CTC - Family Planning Method'), `conp`.`value`, NULL))         AS `FamilyPlannigMethod`,
       max(if((`conp`.`name` = 'CTC - TB Screening and Dx'), `conp`.`value`, NULL))            AS `TBScreening`,
       max(if((`conp`.`name` = 'CTC - TB Rx'), `conp`.`value`, NULL))                          AS `TBRxStatus`,
       max(if((`conp`.`name` = 'CTC - IPT'), `conp`.`value`, NULL))                            AS `IPTStatus`,
       max(if((`conp`.`name` = 'CTC - ARV Status'), `conp`.`value`, NULL))                     AS `ARVStatus`,
       max(if((`conp`.`name` = 'CTC - ARV Start'), `conp`.`value`, NULL))                      AS `ARVReasonToStart`,
       `conorder`.`value`                                                                      AS `ARVCombinationRegimen`,
       (select `os`.`name`
        from (`openmrs`.`order_set_member` `osm` join `openmrs`.`order_set` `os`
              on ((`osm`.`order_set_id` = `os`.`order_set_id`)))
        where `osm`.`concept_id` in (select `ctc_regimen_fetcher`.`name`
                                     from `openmrs`.`ctc_regimen_fetcher`
                                     where (`ctc_regimen_fetcher`.`encounter_id` = `en`.`encounter_id`))
        group by `osm`.`order_set_id`
        having (count(0) = 3)
        limit 1)                                                                               AS `regimenName`,
       (select `os`.`description`
        from (`openmrs`.`order_set_member` `osm` join `openmrs`.`order_set` `os`
              on ((`osm`.`order_set_id` = `os`.`order_set_id`)))
        where `osm`.`concept_id` in (select `ctc_regimen_fetcher`.`name`
                                     from `openmrs`.`ctc_regimen_fetcher`
                                     where (`ctc_regimen_fetcher`.`encounter_id` = `en`.`encounter_id`))
        group by `osm`.`order_set_id`
        having (count(0) = 3)
        limit 1)                                                                               AS `regimenLineName`,
       `conorder`.`dispenseDays`                                                               AS `NoOfDaysDispensed`,
       max(if((`conp`.`name` = 'CTC - ARV Adherence Status'), `conp`.`value`, NULL))           AS `ARVAdhereStatus`,
       max(if((`conp`.`name` = 'CTC - Client Category on ART'), `conp`.`value`, NULL))         AS `ClientCategory`,
       `conoi`.`value`                                                                         AS `OIMedicine`,
       max(if((`conp`.`name` = 5106), `conp`.`value`, NULL))                                   AS `Haemoglobin`,
       max(if((`conp`.`name` = 4261), `conp`.`value`, NULL))                                   AS `ALT`,
       max(if((`conp`.`name` = 4261), `conp`.`value`, NULL))                                   AS `SerumCreatinin`,
       max(if((`conp`.`name` = 'CTC - Nutritional Status'), `conp`.`value`, NULL))             AS `NutritionStatus`,
       max(if((`conp`.`name` = 'CTC - Nutritional Supplement'), `conp`.`value`, NULL))         AS `NutritionSupplement`,
       max(if((`conp`.`name` = 3553), `conp`.`value`, NULL))                                   AS `ReferralTo`,
       (select min(`openmrs`.`patient_appointment`.`start_date_time`) AS `app_date`
        from `openmrs`.`patient_appointment`
        where ((`openmrs`.`patient_appointment`.`patient_id` = `v`.`patient_id`) and
               (`openmrs`.`patient_appointment`.`appointment_service_id` = 2)))                AS `NextVisit`,
       max(if((`conp`.`name` = 3319), `conp`.`value`, NULL))                                   AS `FollowUpStatus`,
       max(if((`conp`.`name` = 3557), `conp`.`value`, NULL))                                   AS `NameOFCLinician`,
       max(if((`conplab`.`value` = 'Urinalysis'), `conplab`.`result`, NULL))                   AS `ViralLoadResult`
from ((((((((((((((`openmrs`.`visit` `v` join `openmrs`.`person_name` `pn`
                   on (((`v`.`patient_id` = `pn`.`person_id`) and (`pn`.`voided` = 0) and
                        (`v`.`visit_type_id` = 9)))) join `openmrs`.`patient_identifier` `pi`
                  on ((`v`.`patient_id` = `pi`.`patient_id`))) join `openmrs`.`patient_program` `pp`
                 on (((`pp`.`patient_id` = `pi`.`patient_id`) and (`pp`.`program_id` = 1)))) join `openmrs`.`program` `prog`
                on ((`pp`.`program_id` = `prog`.`program_id`))) join `openmrs`.`encounter` `en`
               on ((`en`.`visit_id` = `v`.`visit_id`))) join `openmrs`.`patient_program_attribute` `attr`
              on (((`pp`.`patient_program_id` = `attr`.`patient_program_id`) and
                   (`attr`.`attribute_type_id` = 1)))) join `openmrs`.`patient_identifier_type` `pit`
             on ((`pi`.`identifier_type` = `pit`.`patient_identifier_type_id`))) join `openmrs`.`global_property` `gp`
            on (((`gp`.`property` = 'bahmni.primaryIdentifierType') and
                 (`gp`.`property_value` = `pit`.`uuid`)))) join `openmrs`.`person` `p`
           on ((`p`.`person_id` = `v`.`patient_id`))) left join `openmrs`.`ctc_concept` `conp`
          on ((`conp`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`ctc_concept_labtest` `conplab`
         on ((`conplab`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`ctc_concept_order` `conorder`
        on ((`conorder`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`ctc_concept_oi` `conoi`
       on ((`conoi`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`visit_attribute` `va`
      on ((`va`.`visit_id` = `v`.`visit_id`)));

