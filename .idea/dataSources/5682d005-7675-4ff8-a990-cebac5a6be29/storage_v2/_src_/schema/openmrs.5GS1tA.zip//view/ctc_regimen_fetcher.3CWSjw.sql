create view ctc_regimen_fetcher as
select 1 AS `name`, 1 AS `encounter_id`;

