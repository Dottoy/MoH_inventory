create view concept_reference_term_map_view as
select 1 AS `concept_id`,
       1 AS `concept_map_type_name`,
       1 AS `code`,
       1 AS `concept_reference_term_name`,
       1 AS `concept_reference_source_name`;

