create view concept_view as
select `openmrs`.`concept`.`concept_id`              AS `concept_id`,
       `concept_full_name`.`name`                    AS `concept_full_name`,
       `concept_short_name`.`name`                   AS `concept_short_name`,
       `openmrs`.`concept_class`.`name`              AS `concept_class_name`,
       `openmrs`.`concept_datatype`.`name`           AS `concept_datatype_name`,
       `openmrs`.`concept`.`retired`                 AS `retired`,
       `openmrs`.`concept_description`.`description` AS `description`,
       `openmrs`.`concept`.`date_created`            AS `date_created`
from (((((`openmrs`.`concept` left join `openmrs`.`concept_name` `concept_full_name` on ((
        (`concept_full_name`.`concept_id` = `openmrs`.`concept`.`concept_id`) and
        (`concept_full_name`.`concept_name_type` = 'FULLY_SPECIFIED') and (`concept_full_name`.`locale` = 'en') and
        (`concept_full_name`.`voided` = 0)))) left join `openmrs`.`concept_name` `concept_short_name` on ((
        (`concept_short_name`.`concept_id` = `openmrs`.`concept`.`concept_id`) and
        (`concept_short_name`.`concept_name_type` = 'SHORT') and (`concept_short_name`.`locale` = 'en') and
        (`concept_short_name`.`voided` = 0)))) left join `openmrs`.`concept_class` on ((
        `openmrs`.`concept_class`.`concept_class_id` =
        `openmrs`.`concept`.`class_id`))) left join `openmrs`.`concept_datatype` on ((
        `openmrs`.`concept_datatype`.`concept_datatype_id` = `openmrs`.`concept`.`datatype_id`)))
         left join `openmrs`.`concept_description`
                   on ((`openmrs`.`concept_description`.`concept_id` = `openmrs`.`concept`.`concept_id`)));

