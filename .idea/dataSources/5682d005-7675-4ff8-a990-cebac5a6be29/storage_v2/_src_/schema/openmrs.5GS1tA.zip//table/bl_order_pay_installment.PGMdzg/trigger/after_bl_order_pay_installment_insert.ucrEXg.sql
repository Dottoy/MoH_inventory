create definer = `openmrs-user`@localhost trigger after_bl_order_pay_installment_insert
    after insert
    on bl_order_pay_installment
    for each row
begin
                    declare totalOrderLinePayment double;
                    declare payableAmount double;
                    declare quoteLineId int;
                    declare orderId int;
                    declare frequency int;
                    SET orderId = (select sale_order_quote from bl_sale_order_by_quote_line where soql_no=NEW.soql_no);
                    SET quoteLineId = (select quote_line from bl_sale_order_by_quote_line where bl_sale_order_by_quote_line.soql_no = NEW.soql_no);
                    SET payableAmount = (select payable_amount from bl_sale_quote_line bsql where bsql.quote_line_id=quoteLineId and bsql.status < 7);
                    SET totalOrderLinePayment = (select sum(bl_order_pay_installment.paid_amount) from bl_order_pay_installment where soql_no = NEW.soql_no);
                    SET frequency = (select count(*) from (select distinct receipt from bl_order_pay_installment where receipt <> NEW.receipt and soql_no = NEW.soql_no) data);
                    update bl_sale_order_by_quote_line set paid_amount = totalOrderLinePayment, debt_amount = (payableAmount-totalOrderLinePayment) where soql_no=NEW.soql_no;
                    update bl_sale_order_by_quote set installment_frequency = frequency where soq_no = orderId;
                end;

