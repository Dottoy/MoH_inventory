create view vw_bl_order_pay_installment_unique as
select min(`bopi`.`entry_no`) AS `entry_no`, `bopi`.`soql_no` AS `soql_no`, `bopi`.`receipt` AS `receipt`
from `openmrs`.`bl_order_pay_installment` `bopi`
group by `bopi`.`soql_no`;

