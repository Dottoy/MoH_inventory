create view ctc_reg_conc as
select `ppa`.`attribute_type_id`  AS `attrid`,
       `pat`.`name`               AS `name`,
       `ppa`.`value_reference`    AS `value`,
       `ppa`.`patient_program_id` AS `patient_program_id`
from (`openmrs`.`patient_program_attribute` `ppa`
         left join `openmrs`.`program_attribute_type` `pat`
                   on ((`pat`.`program_attribute_type_id` = `ppa`.`attribute_type_id`)))
where (`pat`.`name` in
       ('ID_Number', 'Referred From', 'Transfer In', 'Name of Treatment Supporter', 'Tel No of Treatment Supporter',
        'Name of Community Support Organisation', 'Date Joined Community Support Group', 'Drug Allergies',
        'Prior ARV Exposure', 'TB Registration No', 'CBHS NUMBER', 'Date Diagnosed HIV+', 'Date Verified HIV Status',
        'Date Ready to Start ARV', 'Date Start ARV', 'WHO Stage', 'CD4 Count', 'Breast Feeding', 'Pregnant'));

