create view diagnosis_obs as
select 1 AS `yrname`, 1 AS `identifier`, 1 AS `visit_date`, 1 AS `name`, 1 AS `diagnosis_occur`;

