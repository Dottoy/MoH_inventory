create view diagnosis_concept_view as
select 1 AS `concept_id`,
       1 AS `concept_full_name`,
       1 AS `concept_short_name`,
       1 AS `concept_class_name`,
       1 AS `concept_datatype_name`,
       1 AS `retired`,
       1 AS `description`,
       1 AS `date_created`,
       1 AS `icd10_code`;

