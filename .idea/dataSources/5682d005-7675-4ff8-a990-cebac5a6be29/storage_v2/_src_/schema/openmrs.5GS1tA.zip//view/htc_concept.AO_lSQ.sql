create view htc_concept as
select 1 AS `name`, 1 AS `obs_group_id`, 1 AS `encounter_id`, 1 AS `value`;

