create view ctc_concept as
select `cv`.`concept_id`                                                                                           AS `concept_id`,
       `cv`.`concept_full_name`                                                                                    AS `name`,
       `o`.`obs_group_id`                                                                                          AS `obs_group_id`,
       `o`.`encounter_id`                                                                                          AS `encounter_id`,
       coalesce(`answer_concept`.`concept_full_name`, `o`.`value_datetime`, `o`.`value_numeric`,
                `o`.`value_text`)                                                                                  AS `value`
from ((`openmrs`.`obs` `o` join `openmrs`.`concept_view` `cv` on (((`cv`.`concept_id` = `o`.`concept_id`) and (`o`.`voided` = 0))))
         left join `openmrs`.`concept_view` `answer_concept` on ((`answer_concept`.`concept_id` = `o`.`value_coded`)))
where (`cv`.`concept_full_name` in
       ('CTC - WHO clinical stage (1 - 4)', 'Signs and Symptoms and OIs', 'CTC - Other Signs Symptoms and OIs',
        'CTC - Functional Status', 'CTC - Pregnant Y/N', 'CTC - EDD', 'CTC - ANC Number',
        'CTC - Family Planning Method', 'CTC - TB Screening and Dx', 'CTC - TB Rx',
        'Insert Date for TB Rx (Start, Complete,Stop and restart)', 'CTC - IPT',
        'Insert Date for IPT (Start, Continue month,Complete,Stop and restart)', 'Number of Days Dispensed IPT Drugs',
        'CTC - ARV Status', 'CTC - ARV Reason - No Start', 'CTC - ARV Start', 'CTC - ARV Reasons - for Substitution',
        'CTC - ARV Reason - Reason for Regimen Switch', 'CTC - ARV Reason - Restart', 'CTC - ARV Reason - Stop',
        'CTC - ARV Specify Other Reason', 'CTC - Client Category on ART', 'Weight', 'CTC - ARV Adherence Status',
        'CTC - Functional Status', 'CTC - Nutritional Supplement', 'CTC - Nutritional Status'));

