create definer = root@localhost trigger create_updateOrderSale
    after insert
    on wh_order_line
    for each row
BEGIN
    SET @COUNT=(SELECT COUNT(*) FROM wh_order_sumUp WHERE (order_id=NEW.order_id AND paid_status=0 AND cancelled_statues=0));
    IF @COUNT=0 THEN
        INSERT INTO wh_order_sumUp (order_id,total_amount,date_ordered,patient_id ) VALUES 
        (NEW.order_id ,(NEW.amount * NEW.qty), NEW.date_ordered, NEW.patient_id); 
    ELSE
        UPDATE wh_order_sumUp SET wh_order_sumUp.total_amount=wh_order_sumUp.total_amount +(NEW.amount * NEW.qty)
        WHERE order_id=NEW.order_id;
    END IF;
    END;

