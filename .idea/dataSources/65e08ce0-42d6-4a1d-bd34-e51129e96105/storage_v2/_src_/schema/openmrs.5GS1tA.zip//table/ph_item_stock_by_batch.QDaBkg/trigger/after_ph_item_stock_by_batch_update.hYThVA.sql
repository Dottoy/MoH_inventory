create definer = `openmrs-user`@localhost trigger after_ph_item_stock_by_batch_update
    after update
    on ph_item_stock_by_batch
    for each row
begin
            declare quantity_to_update int;
            declare quantity_current_on_hand int;
            declare added_amount int;
            declare reduced_amount int;

            declare transaction_hack_uuid varchar(80);
            declare transaction_source_uuid varchar(80);
            declare transaction_uuid varchar(80);
            declare prescription_order int;
            declare transaction_id int;
            declare transaction_source_id int;
            declare transaction_creator_id int;

            declare completed int;
            declare rows int;

            SET transaction_hack_uuid = NEW.latest_transaction_map;
            SET transaction_uuid = uuid();
            SET rows=(select count(*) from ph_item_stock_on_hand pisoh where(pisoh.store_id=NEW.store_id and pisoh.item_id=NEW.item_id));
            SET transaction_source_uuid = (select pitmh1.latest_transaction_source_uuid from ph_item_transaction_map_hack pitmh1 where pitmh1.entry_uuid = transaction_hack_uuid);
            SET transaction_creator_id = (select pitmh2.creator from ph_item_transaction_map_hack pitmh2 where pitmh2.entry_uuid = transaction_hack_uuid);
            SET transaction_source_id = (select pits.transaction_source_id from ph_item_transaction_source pits where pits.uuid = transaction_source_uuid);
            SET completed = (select pitmh2.completed from ph_item_transaction_map_hack pitmh2 where pitmh2.entry_uuid = transaction_hack_uuid);
            SET quantity_current_on_hand=(select quantity from ph_item_stock_on_hand pisoh where(pisoh.store_id=NEW.store_id and pisoh.item_id=NEW.item_id));

            if rows=0 then
            insert into ph_item_stock_on_hand(store_id,item_id,quantity,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.quantity,transaction_creator_id,now(),uuid());
            if transaction_source_id is not null and transaction_source_id > 0 then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.quantity,'0',NEW.quantity,'1',transaction_source_id,transaction_creator_id,now(),transaction_uuid);
            end if;
            if transaction_source_id is null then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,NEW.quantity,'0',NEW.quantity,'1','0',transaction_creator_id,now(),transaction_uuid);
            end if;
            SET transaction_id = (select pit2.transaction_id from ph_item_transaction pit2 where uuid = transaction_uuid);
            SET prescription_order = (select pitmh3.prescription_order from ph_item_transaction_map_hack pitmh3 where pitmh3.entry_uuid = transaction_hack_uuid);
            if transaction_id > 0 then
            if transaction_source_uuid = '4ba23772-329b-4fc6-a8cd-f33d5596c8bc' and prescription_order > 0 then
            insert into ph_item_transaction_dispense (transaction_id, prescription_order) values(transaction_id,prescription_order);
            end if;
            if completed = 1 then
            delete from ph_item_transaction_map_hack where entry_uuid = NEW.latest_transaction_map;
            end if;
            end if;
            end if;
            if rows > 0 then
            if NEW.quantity > OLD.quantity then
            SET added_amount=NEW.quantity-OLD.quantity;
            SET quantity_to_update=quantity_current_on_hand+added_amount;
            update ph_item_stock_on_hand pisoh set pisoh.quantity=quantity_to_update,pisoh.date_changed=now(),pisoh.changed_by=transaction_creator_id where(pisoh.store_id=NEW.store_id and pisoh.item_id=NEW.item_id);

            if transaction_source_id is not null and transaction_source_id > 0 then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,added_amount,quantity_current_on_hand,quantity_to_update,'1',transaction_source_id,transaction_creator_id,now(),transaction_uuid);
            end if;
            if transaction_source_id is null then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,added_amount,quantity_current_on_hand,quantity_to_update,'1','0',transaction_creator_id,now(),transaction_uuid);
            end if;

            SET transaction_id = (select transaction_id from ph_item_transaction where uuid = transaction_uuid);
            SET prescription_order = (select pitmh4.prescription_order from ph_item_transaction_map_hack pitmh4 where pitmh4.entry_uuid = transaction_hack_uuid);

            if transaction_id > 0 then
            if transaction_source_uuid = '4ba23772-329b-4fc6-a8cd-f33d5596c8bc' and prescription_order > 0 then
            insert into ph_item_transaction_dispense (transaction_id, prescription_order) values(transaction_id,prescription_order);
            end if;
            if completed = 1 then
            delete from ph_item_transaction_map_hack where entry_uuid = transaction_hack_uuid;
            end if;
            end if;
            end if;
            if NEW.quantity < OLD.quantity then
            SET reduced_amount=OLD.quantity-NEW.quantity;
            SET quantity_to_update=quantity_current_on_hand-reduced_amount;
            update ph_item_stock_on_hand pisoh set pisoh.quantity=quantity_to_update,pisoh.date_changed=now(),pisoh.changed_by=transaction_creator_id where(pisoh.store_id=NEW.store_id and pisoh.item_id=NEW.item_id);

            if transaction_source_id is not null and transaction_source_id > 0 then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,reduced_amount,quantity_current_on_hand,quantity_to_update,'2',transaction_source_id,transaction_creator_id,now(),transaction_uuid);
            end if;
            if transaction_source_id is null then
            insert into ph_item_transaction(store_id,item_id,batch_no,transaction_quantity,quantity_before,quantity_after,transaction_type_id,transaction_source_id,creator,date_created,uuid) values(NEW.store_id,NEW.item_id,NEW.batch_no,reduced_amount,quantity_current_on_hand,quantity_to_update,'2','0',transaction_creator_id,now(),transaction_uuid);
            end if;

            SET transaction_id = (select pit4.transaction_id from ph_item_transaction pit4 where uuid = transaction_uuid);
            SET prescription_order = (select pitmh9.prescription_order from ph_item_transaction_map_hack pitmh9 where pitmh9.entry_uuid = NEW.latest_transaction_map);

            if transaction_id > 0 then
            if transaction_source_uuid = '4ba23772-329b-4fc6-a8cd-f33d5596c8bc' and prescription_order > 0 then
            insert into ph_item_transaction_dispense (transaction_id, prescription_order) values(transaction_id,prescription_order);
            end if;
            if completed = 1 then
            delete from ph_item_transaction_map_hack where entry_uuid = NEW.latest_transaction_map;
            end if;
            end if;
            end if;
            end if;
            end;

