create definer = `openmrs-user`@localhost trigger after_bl_sale_order_by_quote_line_insert
    after insert
    on bl_sale_order_by_quote_line
    for each row
begin
                declare rows int;
                declare payableAmountQuote double;
                declare payableAmountOrder double;
                declare totalPayableOrder double;

                SET payableAmountQuote = (select payable_amount from bl_sale_quote_line bsql where bsql.quote_line_id=NEW.quote_line and bsql.status < 7);
                SET payableAmountOrder = (select payable_amount from bl_sale_order_by_quote bsobq where bsobq.soq_no=NEW.sale_order_quote);
                SET totalPayableOrder = payableAmountOrder+payableAmountQuote;
                SET rows = (select count(*) from bl_sale_order_by_quote_line where soql_no = NEW.soql_no);

                if rows < 2 then
                    update bl_sale_quote_line set status = 6 where quote_line_id = NEW.quote_line;
                end if;
                update bl_sale_order_by_quote set payable_amount=totalPayableOrder, debt_amount = totalPayableOrder where soq_no = NEW.sale_order_quote;
            end;

