create definer = root@localhost view tb_visit_card as
select `pi`.`identifier`                                                          AS `PatientID`,
       max(if((`attr`.`attribute_type_id` = 49), `attr`.`value_reference`, NULL)) AS `District Registration Number`,
       concat(`pn`.`given_name`, ' ', `pn`.`family_name`)                         AS `PatientName`,
       floor(((to_days(curdate()) - to_days(`p`.`birthdate`)) / 365))             AS `AgeToDate`,
       `p`.`gender`                                                               AS `Gender`,
       `v`.`date_started`                                                         AS `visitStartDate`,
       max(if((`conplab`.`value` = 'Smear'), `conplab`.`value`, NULL))            AS `Smear`,
       max(if((`conplab`.`value` = 'HIV Test'), `conplab`.`value`, NULL))         AS `HIV Test`
from ((((((((((((((`openmrs`.`visit` `v` join `openmrs`.`person_name` `pn` on (((`v`.`patient_id` = `pn`.`person_id`) and (`pn`.`voided` = 0)))) join `openmrs`.`patient_identifier` `pi` on ((`v`.`patient_id` = `pi`.`patient_id`))) join `openmrs`.`patient_program` `pp` on (((`pp`.`patient_id` = `pi`.`patient_id`) and (`pp`.`program_id` = 2)))) join `openmrs`.`program` `prog` on ((`pp`.`program_id` = `prog`.`program_id`))) join `openmrs`.`encounter` `en` on ((`en`.`visit_id` = `v`.`visit_id`))) join `openmrs`.`patient_program_attribute` `attr` on ((`pp`.`patient_program_id` = `attr`.`patient_program_id`))) join `openmrs`.`patient_identifier_type` `pit` on ((`pi`.`identifier_type` = `pit`.`patient_identifier_type_id`))) join `openmrs`.`global_property` `gp` on ((
        (`gp`.`property` = 'bahmni.primaryIdentifierType') and
        (`gp`.`property_value` = `pit`.`uuid`)))) join `openmrs`.`person` `p` on ((`p`.`person_id` = `v`.`patient_id`))) left join `openmrs`.`ctc_concept` `conp` on ((`conp`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`ctc_concept_labtest` `conplab` on ((`conplab`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`ctc_concept_order` `conorder` on ((`conorder`.`encounter_id` = `en`.`encounter_id`))) left join `openmrs`.`ctc_concept_oi` `conoi` on ((`conoi`.`encounter_id` = `en`.`encounter_id`)))
         left join `openmrs`.`visit_attribute` `va` on ((`va`.`visit_id` = `v`.`visit_id`)))
where (`v`.`visit_type_id` = 10)
group by `v`.`date_started`
order by `v`.`date_started` desc;

