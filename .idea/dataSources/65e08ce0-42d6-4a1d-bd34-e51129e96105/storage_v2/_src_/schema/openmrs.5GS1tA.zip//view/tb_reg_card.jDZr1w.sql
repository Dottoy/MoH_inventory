create definer = root@localhost view tb_reg_card as
select `pi`.`identifier` AS                                                                      `PatientID`,
       concat(`pn`.`given_name`, ' ', `pn`.`family_name`) AS                                     `PatientName`,
       floor(((to_days(curdate()) - to_days(`p`.`birthdate`)) / 365)) AS                         `AgeToDate`,
       `p`.`gender` AS                                                                           `Gender`,
       concat(`pa`.`address2`, ' ', `pa`.`address3`, ' ', `pa`.`address4`) AS                    `Address`,
       max(if((`pat`.`person_attribute_type_id` = 44), `pat`.`value`, NULL)) AS                  `Next Kin Name`,
       max(if((`pat`.`person_attribute_type_id` = 45), `pat`.`value`, NULL)) AS                  `Next Kin Mobile No`,
       max(if((`conp`.`name` = 'District Registration Number'), `conp`.`value`,
              NULL)) AS                                                                          `District Registration Number`,
       (select `openmrs`.`patient_program`.`date_enrolled`
        from `openmrs`.`patient_program`
        where (`openmrs`.`patient_program`.`patient_program_id` = `pp`.`patient_program_id`)) AS `EnrollmentDate`,
       max(if((`conp`.`name` = 'Place of Work'), (select `concept_view`.`concept_short_name`
                                                  from `openmrs`.`concept_view`
                                                  where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL)) AS                                                                          `PlaceOfWork`,
       max(if((`conp`.`name` = 'Place of Work-Other'), `conp`.`value`, NULL)) AS                 `PlaceOfWorkOther`,
       max(if((`conp`.`name` = 'Reffered by'), (select `concept_view`.`concept_short_name`
                                                from `openmrs`.`concept_view`
                                                where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL)) AS                                                                          `RefferedBy`,
       max(if((`conp`.`name` = 'Reffered by-Other'), `conp`.`value`, NULL)) AS                   `RefferedByOther`,
       max(if((`conp`.`name` = 'DOT Option'), (select `concept_view`.`concept_short_name`
                                               from `openmrs`.`concept_view`
                                               where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL)) AS                                                                          `DOTOption`,
       max(if((`conp`.`name` = 'Name of Treatment Supporter'), `conp`.`value`,
              NULL)) AS                                                                          `NameOfTreatmentSupporter`,
       max(if((`conp`.`name` = 'Tel No of Treatment Supporter'), `conp`.`value`,
              NULL)) AS                                                                          `TelNoOfTreatmentSupporter`,
       max(if((`conp`.`name` = 'Physical Address of Treatment Supporter'), `conp`.`value`,
              NULL)) AS                                                                          `PhysicalAddressOfTreatmentSupporter`,
       max(if((`conp`.`name` = 'Name of Community Support Organisation'), `conp`.`value`,
              NULL)) AS                                                                          `NameOfCommunitySupportOrganisation`,
       max(if((`conp`.`name` = 'Classification by site'), (select `concept_view`.`concept_short_name`
                                                           from `openmrs`.`concept_view`
                                                           where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL)) AS                                                                          `ClassificationBySite`,
       max(if((`conp`.`name` = 'Site'), `conp`.`value`, NULL)) AS                                `Site`,
       max(if((`conp`.`name` = 'Classification by History of Treatment'), (select `concept_view`.`concept_short_name`
                                                                           from `openmrs`.`concept_view`
                                                                           where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL)) AS                                                                          `ClassificationByHistoryOfTreatment`,
       max(if((`conp`.`name` = 'HIV Status'), (select `concept_view`.`concept_short_name`
                                               from `openmrs`.`concept_view`
                                               where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL)) AS                                                                          `HIVStatus`,
       max(if((`conp`.`name` = 'HIV Care registration number'), `conp`.`value`,
              NULL)) AS                                                                          `HIV Care registration number`,
       max(if((`conp`.`name` = 'CPT'), `conp`.`value`, NULL)) AS                                 `CPT`,
       max(if((`conp`.`name` = 'CPT Start Date'), `conp`.`value`, NULL)) AS                      `CPTStartDate`,
       max(if((`conp`.`name` = 'ART drugs'), `conp`.`value`, NULL)) AS                           `ARTDrugs`,
       max(if((`conp`.`name` = 'ART Start Date'), `conp`.`value`, NULL)) AS                      `ARTStartDate`
from (((((((`openmrs`.`patient_program` `pp` join `openmrs`.`patient_identifier` `pi` on ((`pp`.`patient_id` = `pi`.`patient_id`))) join `openmrs`.`person_name` `pn` on ((`pp`.`patient_id` = `pn`.`person_id`))) join `openmrs`.`person_address` `pa` on ((`pa`.`person_id` = `pn`.`person_id`))) join `openmrs`.`person` `p` on ((`p`.`person_id` = `pp`.`patient_id`))) join `openmrs`.`person_attribute` `pat` on ((`pat`.`person_id` = `pn`.`person_id`))) join `openmrs`.`person_attribute_type` `paty` on ((`paty`.`person_attribute_type_id` = `pat`.`person_attribute_type_id`)))
         left join `openmrs`.`tb_reg_conc` `conp` on ((`conp`.`patient_program_id` = `pp`.`patient_program_id`)))
where (`pp`.`program_id` = 2)
group by `pp`.`patient_program_id`;

