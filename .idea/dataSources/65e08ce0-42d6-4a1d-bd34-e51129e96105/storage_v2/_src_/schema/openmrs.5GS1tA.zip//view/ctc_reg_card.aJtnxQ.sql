create definer = root@localhost view ctc_reg_card as
select `pi`.`identifier`                                                                                             AS `PatientID`,
       concat(`pn`.`given_name`, ' ', `pn`.`family_name`)                                                            AS `PatientName`,
       floor(((to_days(curdate()) - to_days(`p`.`birthdate`)) / 365))                                                AS `AgeToDate`,
       `p`.`gender`                                                                                                  AS `Gender`,
       max(if((`conp`.`name` = 'ID_Number'), `conp`.`value`, NULL))                                                  AS `CTCID`,
       (select `openmrs`.`patient_program`.`date_enrolled`
        from `openmrs`.`patient_program`
        where (`openmrs`.`patient_program`.`patient_program_id` =
               `pp`.`patient_program_id`))                                                                           AS `EnrollmentDate`,
       max(if((`conp`.`name` = 'Referred From'), (select `concept_view`.`concept_full_name`
                                                  from `openmrs`.`concept_view`
                                                  where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL))                                                                                                 AS `ReferredFrom`,
       max(if((`conp`.`name` = 'Transfer In'), (select `concept_view`.`concept_full_name`
                                                from `openmrs`.`concept_view`
                                                where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL))                                                                                                 AS `TransferIn`,
       max(if((`conp`.`name` = 'Name of Treatment Supporter'), `conp`.`value`,
              NULL))                                                                                                 AS `NameOfSupporter`,
       max(if((`conp`.`name` = 'Tel No of Treatment Supporter'), `conp`.`value`,
              NULL))                                                                                                 AS `TelTreatSupporter`,
       max(if((`conp`.`name` = 'Name of Community Support Organisation'), `conp`.`value`,
              NULL))                                                                                                 AS `CommunityOrg`,
       max(if((`conp`.`name` = 'Date Joined Community Support Group'), `conp`.`value`,
              NULL))                                                                                                 AS `DateJoined`,
       max(if((`conp`.`name` = 'Drug Allergies'), `conp`.`value`, NULL))                                             AS `DrugAllergies`,
       max(if((`conp`.`name` = 'Prior ARV Exposure'), (select `concept_view`.`concept_full_name`
                                                       from `openmrs`.`concept_view`
                                                       where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL))                                                                                                 AS `PriorARVExposure`,
       max(
               if((`conp`.`name` = 'TB Registration No'), `conp`.`value`, NULL))                                     AS `TBRegNo`,
       max(if((`conp`.`name` = 'CBHS NUMBER'), `conp`.`value`, NULL))                                                AS `CBHSNo`,
       max(
               if((`conp`.`name` = 'Date Diagnosed HIV+'), `conp`.`value`, NULL))                                    AS `DateDiagnosedHIV+`,
       max(if((`conp`.`name` = 'Date Verified HIV Status'), `conp`.`value`,
              NULL))                                                                                                 AS `DateVerifyIVStatus`,
       max(if((`conp`.`name` = 'Date Ready to Start ARV'), `conp`.`value`,
              NULL))                                                                                                 AS `DateReadyToStart`,
       max(if((`conp`.`name` = 'Date Start ARV'), `conp`.`value`, NULL))                                             AS `DateStartARV`,
       max(if((`conp`.`name` = 'WHO Stage'), (select `concept_view`.`concept_full_name`
                                              from `openmrs`.`concept_view`
                                              where (`concept_view`.`concept_id` = `conp`.`value`)),
              NULL))                                                                                                 AS `WHOStage`,
       max(if((`conp`.`name` = 'CD4 Count'), `conp`.`value`, NULL))                                                  AS `CD4Count`,
       max(if((`conp`.`name` = 'Breast Feeding'), `conp`.`value`, NULL))                                             AS `BreastFeeding`,
       max(if((`conp`.`name` = 'Pregnant'), `conp`.`value`, NULL))                                                   AS `Pregnant`,
       (select `concept_view`.`concept_full_name`
        from `openmrs`.`concept_view`
        where (`concept_view`.`concept_id` = `pp`.`outcome_concept_id`))                                             AS `FollowUpStatus`
from ((((`openmrs`.`patient_program` `pp` join `openmrs`.`patient_identifier` `pi` on ((`pp`.`patient_id` = `pi`.`patient_id`))) join `openmrs`.`person_name` `pn` on ((`pp`.`patient_id` = `pn`.`person_id`))) join `openmrs`.`person` `p` on ((`p`.`person_id` = `pp`.`patient_id`)))
         left join `openmrs`.`ctc_reg_conc` `conp` on ((`conp`.`patient_program_id` = `pp`.`patient_program_id`)))
where (`pp`.`program_id` = 1)
group by `pp`.`patient_program_id`;

