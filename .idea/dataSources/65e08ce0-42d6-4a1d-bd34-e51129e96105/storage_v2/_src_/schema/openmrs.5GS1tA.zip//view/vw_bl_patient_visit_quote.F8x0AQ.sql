create definer = root@localhost view vw_bl_patient_visit_quote as
select `bsq`.`patient`                    AS `patient`,
       `vpv`.`patient_name`               AS `patient_name`,
       `vpv`.`sex`                        AS `sex`,
       `vpv`.`birthdate`                  AS `birthdate`,
       `vpv`.`patient_identifier`         AS `patient_identifier`,
       `vpv`.`patient_uuid`               AS `patient_uuid`,
       `vpv`.`patient_creator`            AS `patient_creator`,
       `bsq`.`visit`                      AS `visit`,
       `vt`.`name`                        AS `visit_type`,
       `v`.`date_started`                 AS `visit_start_date`,
       `v`.`date_stopped`                 AS `visit_stop_date`,
       `vpv`.`visit_validity`             AS `visit_validity`,
       `vpv`.`visit_creator`              AS `visit_creator`,
       `vpv`.`visit_uuid`                 AS `visit_uuid`,
       `bsq`.`quote_id`                   AS `sale_quote_id`,
       `bqsc_main`.`name`                 AS `main_quote_status`,
       `bsql`.`quote_line_id`             AS `quote_line_id`,
       `bsql`.`date_created`              AS `date_quoted`,
       `vbfvip`.`payment_category_id`     AS `payment_category_id`,
       `vbfvip`.`payment_sub_category_id` AS `payment_sub_category_id`,
       `vbfvip`.`payment_category`        AS `payment_category`,
       `vbfvip`.`payment_sub_category`    AS `payment_sub_category`,
       `vbfvip`.`service_type_id`         AS `service_type_id`,
       `vbfvip`.`service_type_name`       AS `service_type_name`,
       `vbfvip`.`item_id`                 AS `item_id`,
       `vbfvip`.`item_name`               AS `item_name`,
       `vbfvip`.`selling_price`           AS `unit_price`,
       `bsql`.`quantity`                  AS `items_quantity`,
       `bsql`.`unit`                      AS `units`,
       `bsql`.`quoted_amount`             AS `quoted_amount`,
       `bsql`.`payable_amount`            AS `payable_amount`,
       `bqsc_line`.`name`                 AS `quote_line_status`
from (((((((((((`openmrs`.`bl_sale_quote` `bsq` left join `openmrs`.`visit` `v` on ((`bsq`.`visit` = `v`.`visit_id`))) left join `openmrs`.`visit_type` `vt` on ((`v`.`visit_type_id` = `vt`.`visit_type_id`))) left join `openmrs`.`bl_sale_quote_line` `bsql` on ((`bsql`.`sale_quote` = `bsq`.`quote_id`))) left join `openmrs`.`bl_quote_status_code` `bqsc_main` on ((`bqsc_main`.`status_code_id` = `bsq`.`status`))) left join `openmrs`.`bl_quote_status_code` `bqsc_line` on ((`bqsc_line`.`status_code_id` = `bsql`.`status`))) left join `openmrs`.`vw_bl_financial_version_item_price` `vbfvip` on ((`vbfvip`.`item_price_id` = `bsql`.`item_price`))) left join `openmrs`.`concept` `c` on ((`c`.`concept_id` = `bsql`.`payment_category`))) left join `openmrs`.`concept_name` `cn` on ((
        (`cn`.`concept_id` = `c`.`concept_id`) and
        (`cn`.`concept_name_type` = 'FULLY_SPECIFIED')))) left join `openmrs`.`users` `u_orderer` on ((`bsq`.`ordered_by` = `u_orderer`.`user_id`))) left join `openmrs`.`person_name` `pn_orderer` on ((`pn_orderer`.`person_id` = `u_orderer`.`person_id`)))
         left join `openmrs`.`vw_patient_visit` `vpv` on ((`vpv`.`visit_id` = `bsq`.`visit`)));

